var dietHandler={
addDiet: function(foodName, foodGroup, fdate, ftime) {
	databaseHandler.db.transaction (
		function(tx) {
			tx.executeSql(
			"insert into diet(foodName, foodGroup, fdate, ftime) values(?, ?)",
			[foodName, foodGroup, fdate, ftime],
			function(tx, results){},
			function(tx,error) {
			 console.log("Add diet error: " + error.message );	
			}
		  );
		}, 
		function(error){},
		function(){}
	);
},
loadDiets: function(displayDiets){
	databaseHandler.db.readTransaction(
		function(tx){
			tx.executeSql(
				"select * from diet",
				[],
				function(tx, results){
					displayDiets(results);
				},
				function(tx,error){ //TODO: Alert msg
				 console.log("Error loading food list: " + error.message);
				}
			);
	    }
	);
},
deleteDiet: function(_id){
	databaseHandler.db.transaction(
		function(tx){
			tx.executeSql(
				"delete from diet where _id = ?",
				[_id],
				function(tx, results) {},
				function (tx,error){ //TODO pass error message
					console.log("Error while deleting: " + error.message);
				}
			);
			
		}
	);
},
updateDiet: function(_id, newfdname, newfdgroup, newfdDate, newfdTime){
		databaseHandler.db.transaction(
		function(tx){
				tx.executeSql(
					"update diet set foodName=?, foodGroup=?, fdate=?, ftime=? where _id = ?",
					[newfdname, newfdgroup, newfdDate, newfdTime, _id],
					function(tx, result){},
					function(tx, error){
						console.log("Error updating " +error.message);
					});
			}
		);
	
 }
};








