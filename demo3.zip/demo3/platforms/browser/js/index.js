$(document).on("ready", function(){
	databaseHandler.createDatabase();
	// $("#lstDiets").on("tap", "li", function() {
		// alert($(this).find("[name='foodName']").html());
	// });
});

function addDiet(){
	var foodName = $("#fdname").val();
	var foodGroup = $("#fdgroup").val();
	var fdate = $("#fdDate").val();
	var ftime = $("#fdTime").val();
	
	 // if(!foodName){
		// //if(foodName = " "){
		// alert("Food name is required");
	// }
	// else {
		
	// }
	
	var r = confirm("Do you want to add food?" );
		if(r==true) {
			dietHandler.addDiet(foodName, foodGroup, fdate, ftime);
			$("#fdname").val("");
			$("#fdgroup").val("");
			$("#fdDate").val("");
			$("#fdTime").val("");	
		}
}
var currentDiet={
	id: -1,
	name:"",
	group:"",
	date:"",
	time:"",
}

function displayDiets(results){
	
	var length = results.rows.length;
	var lstDiets = $("#lstDiets");
	lstDiets.empty(); //Clean the old data before adding
	for(var i = 0; i< length; i++) {
		var item = results.rows.item(i);
		var a = $("<a />");
		var h1 = $("<h1 />").text("Food name: ");
		var h2 = $("<h2 />").text("Food group: ");
		var h3 = $("<h3 />").text("Date: ");
		var h4 = $("<h4 />").text("Time: ");
		var p = $("<p />").text("Id: ");
		
		var spanName = $("<span />").text(item.foodName);
		spanName.attr("name","foodName");
		
		var spanGroup = $("<span />").text(item.foodGroup);
		spanGroup.attr("name","foodGroup");
		
		var spanDate = $("<span />").text(item.fdate);
		spanDate.attr("name","fdate");
		
		var spanTime = $("<span />").text(item.ftime);
		spanTime.attr("name","ftime");
		
		var spanId = $("<span />").text(item._id);
		spanId.attr("name","_id");
		
		h1.append(spanName);
		h2.append(spanGroup);
		h3.append(spanDate);
		h4.append(spanTime);
		p.append(spanId);
		a.append(h1);
		a.append(h2);
		a.append(h3);
		a.append(h4);
		a.append(p);
		var li = $("<li/>");
		li.attr("data-filtertext", item.foodName);
		li.append(a);
		lstDiets.append(li);
		
	}
	lstDiets.listview("refresh");
	lstDiets.on("tap", "li", function(){
		currentDiet.id = $(this).find("[name='_id']").text();
		currentDiet.name = $(this).find("[name='foodName']").text();
		currentDiet.group = $(this).find("[name='foodGroup']").text();
		currentDiet.date = $(this).find("[name='fdate']").text();
		currentDiet.time = $(this).find("[name='ftime']").text();
		
		//Set event for the list item
	$("#popupUpdateDelete").popup("open");
	});
}

$(document).on("pagebeforeshow", "#loadpage", function(){
	dietHandler.loadDiets(displayDiets);
});

function deleteDiet (){
	var r = confirm("Delete Food Name: "+currentDiet.name)
	
	if(r==true){
		dietHandler.deleteDiet(currentDiet.id);
		dietHandler.loadDiets(displayDiets);
	}
	$("#popupUpdateDelete").popup("close");
}

$(document).on("pagebeforeshow", "updatedialog", function() {
	$("#newfdname").val(currentDiet.name);
	$("#newfdgroup").val(currentDiet.group);
	$("#newfdDate").val(currentDiet.date);
	$("#newfdTime").val(currentDiet.time);
	
	
});

function updateDiet(){
	var newname = $("#newfdname").val();
	var newgroup = $("#newfdgroup").val();
	var newdate = $("#newfdDate").val();
	var newtime = $("#newfdTime").val();
	dietHandler.updateDiet(currentDiet.id, newname, newgroup, newdate, newtime);
	$("#updatedialog").dialog("close");
}








