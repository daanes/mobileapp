var databaseHandler = {
	
	db:null,
	createDatabase: function(){
		this.db = window.openDatabase(
			"diets.db",
			"1.0",
			"diet database",
			100000); 
			this.db.transaction(
			function (tx){
				//Run sql here using tx
				tx.executeSql(
				"create table if not exists diet(_id integer primary key, foodName text, foodGroup text, fdate date, ftime time)",
				[],
				function(tx, results){},
				function(tx, error){
					console.log("Error while creating the table:" + error.message);
				}
			  );	
			
			},
			function (error){
				console.log("Transaction error: " + error.message);
			},
			function(){
				console.log("Create DB transaction successfully"); //console can replace as alert
			}
			
	); 
}
}